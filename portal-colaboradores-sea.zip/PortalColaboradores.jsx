
// Arquivo principal do portal interativo da SEA Telecom
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Calculadoras from './components/Calculadoras';
import LinksUteis from './components/LinksUteis';
import GeradorScripts from './components/GeradorScripts';

export default function PortalColaboradores() {
  return (
    <main className="min-h-screen p-6 bg-gray-50 text-gray-800">
      <h1 className="text-3xl font-bold mb-6">Portal de Colaboradores - SEA Telecom</h1>
      <Tabs defaultValue="calculadoras" className="w-full">
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="calculadoras">📊 Calculadoras</TabsTrigger>
          <TabsTrigger value="scripts">📝 Scripts</TabsTrigger>
          <TabsTrigger value="links">🔗 Links Úteis</TabsTrigger>
        </TabsList>
        <TabsContent value="calculadoras">
          <Calculadoras />
        </TabsContent>
        <TabsContent value="scripts">
          <GeradorScripts />
        </TabsContent>
        <TabsContent value="links">
          <LinksUteis />
        </TabsContent>
      </Tabs>
    </main>
  );
}
